#pragma once
#include "Conversor.h"
#include <iostream>
#include "msclr\marshal_cppstd.h"

namespace Ejenclase {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	using namespace msclr;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  lblBolivianos;
	protected: 
	private: System::Windows::Forms::Label^  lblDolares;
	private: System::Windows::Forms::TextBox^  txtBolivianos;

	private: System::Windows::Forms::TextBox^  txtDolares;





	private: System::Windows::Forms::Button^  btnConvertir;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(Form1::typeid));
			this->lblBolivianos = (gcnew System::Windows::Forms::Label());
			this->lblDolares = (gcnew System::Windows::Forms::Label());
			this->txtBolivianos = (gcnew System::Windows::Forms::TextBox());
			this->txtDolares = (gcnew System::Windows::Forms::TextBox());
			this->btnConvertir = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// lblBolivianos
			// 
			this->lblBolivianos->AutoSize = true;
			this->lblBolivianos->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(224)), static_cast<System::Int32>(static_cast<System::Byte>(224)), 
				static_cast<System::Int32>(static_cast<System::Byte>(224)));
			this->lblBolivianos->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 26.25F, static_cast<System::Drawing::FontStyle>(((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic) 
				| System::Drawing::FontStyle::Underline)), System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->lblBolivianos->ForeColor = System::Drawing::Color::Green;
			this->lblBolivianos->Location = System::Drawing::Point(33, 59);
			this->lblBolivianos->Name = L"lblBolivianos";
			this->lblBolivianos->Size = System::Drawing::Size(186, 39);
			this->lblBolivianos->TabIndex = 0;
			this->lblBolivianos->Text = L"Bolivianos";
			this->lblBolivianos->Click += gcnew System::EventHandler(this, &Form1::lblBolivianos_Click);
			// 
			// lblDolares
			// 
			this->lblDolares->AutoSize = true;
			this->lblDolares->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(224)), static_cast<System::Int32>(static_cast<System::Byte>(224)), 
				static_cast<System::Int32>(static_cast<System::Byte>(224)));
			this->lblDolares->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 26.25F, static_cast<System::Drawing::FontStyle>(((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic) 
				| System::Drawing::FontStyle::Underline)), System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->lblDolares->ForeColor = System::Drawing::Color::Green;
			this->lblDolares->Location = System::Drawing::Point(44, 180);
			this->lblDolares->Name = L"lblDolares";
			this->lblDolares->Size = System::Drawing::Size(144, 39);
			this->lblDolares->TabIndex = 1;
			this->lblDolares->Text = L"Dolares";
			// 
			// txtBolivianos
			// 
			this->txtBolivianos->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->txtBolivianos->ForeColor = System::Drawing::Color::Olive;
			this->txtBolivianos->Location = System::Drawing::Point(260, 59);
			this->txtBolivianos->Name = L"txtBolivianos";
			this->txtBolivianos->Size = System::Drawing::Size(179, 29);
			this->txtBolivianos->TabIndex = 2;
			this->txtBolivianos->TextChanged += gcnew System::EventHandler(this, &Form1::txtBolivianos_TextChanged);
			// 
			// txtDolares
			// 
			this->txtDolares->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->txtDolares->ForeColor = System::Drawing::Color::Olive;
			this->txtDolares->Location = System::Drawing::Point(260, 180);
			this->txtDolares->Name = L"txtDolares";
			this->txtDolares->Size = System::Drawing::Size(179, 29);
			this->txtDolares->TabIndex = 3;
			this->txtDolares->TextChanged += gcnew System::EventHandler(this, &Form1::txtDolares_TextChanged);
			// 
			// btnConvertir
			// 
			this->btnConvertir->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(224)), static_cast<System::Int32>(static_cast<System::Byte>(224)), 
				static_cast<System::Int32>(static_cast<System::Byte>(224)));
			this->btnConvertir->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 21.75F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Underline)), 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->btnConvertir->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(0)), static_cast<System::Int32>(static_cast<System::Byte>(64)), 
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->btnConvertir->Location = System::Drawing::Point(184, 251);
			this->btnConvertir->Name = L"btnConvertir";
			this->btnConvertir->Size = System::Drawing::Size(185, 56);
			this->btnConvertir->TabIndex = 4;
			this->btnConvertir->Text = L"Convertir";
			this->btnConvertir->UseVisualStyleBackColor = false;
			this->btnConvertir->Click += gcnew System::EventHandler(this, &Form1::btnConvertir_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackgroundImage = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"$this.BackgroundImage")));
			this->ClientSize = System::Drawing::Size(543, 375);
			this->Controls->Add(this->btnConvertir);
			this->Controls->Add(this->txtDolares);
			this->Controls->Add(this->txtBolivianos);
			this->Controls->Add(this->lblDolares);
			this->Controls->Add(this->lblBolivianos);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnConvertir_Click(System::Object^  sender, System::EventArgs^  e) {
			Conversor Bs;
		 Bs.Set_Bolivianos(System::Convert::ToInt32(txtBolivianos->Text));
		float Dolaresfin;
		 Dolaresfin=Bs.Convertir();
		 txtDolares->Text=System::Convert::ToString(Dolaresfin); }
private: System::Void txtBolivianos_TextChanged(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void lblBolivianos_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void txtDolares_TextChanged(System::Object^  sender, System::EventArgs^  e) {
		 }
};
}

