#include "StdAfx.h"
#include "Conversor.h"


Conversor::Conversor(void)
{
}
float Conversor::Get_Bolivianos()
{
 return Bolivianos;
}
float Conversor::Get_Dolares()
{
 return Dolares;
}
void Conversor::Set_Bolivianos(int b)
{
 Bolivianos=b;
}
void Conversor::Set_Dolares(int d)
{
 Dolares=d;
}
float Conversor::Convertir()
{
	Dolares=Bolivianos/(6.89);
	return Dolares;

}