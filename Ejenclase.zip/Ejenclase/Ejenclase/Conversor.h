#pragma once
class Conversor
{
	private:
	float Bolivianos;
	float Dolares;

	public:
	Conversor(void);
	float Get_Bolivianos();
	float Get_Dolares();
	void Set_Bolivianos(int b);
	void Set_Dolares(int d);

	float Convertir();
};

