#pragma once

namespace HolaMundo {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  lblMensaje;
	private: System::Windows::Forms::TextBox^  txtMensaje;
	private: System::Windows::Forms::Button^  btnMensaje;
	protected: 

	protected: 

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->lblMensaje = (gcnew System::Windows::Forms::Label());
			this->txtMensaje = (gcnew System::Windows::Forms::TextBox());
			this->btnMensaje = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// lblMensaje
			// 
			this->lblMensaje->AutoSize = true;
			this->lblMensaje->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)), 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->lblMensaje->Location = System::Drawing::Point(31, 29);
			this->lblMensaje->Name = L"lblMensaje";
			this->lblMensaje->Size = System::Drawing::Size(105, 20);
			this->lblMensaje->TabIndex = 0;
			this->lblMensaje->Text = L"Hola Mundo";
			this->lblMensaje->Click += gcnew System::EventHandler(this, &Form1::label1_Click);
			// 
			// txtMensaje
			// 
			this->txtMensaje->Location = System::Drawing::Point(35, 85);
			this->txtMensaje->Name = L"txtMensaje";
			this->txtMensaje->Size = System::Drawing::Size(100, 20);
			this->txtMensaje->TabIndex = 1;
			this->txtMensaje->TextChanged += gcnew System::EventHandler(this, &Form1::txtMensaje_TextChanged);
			// 
			// btnMensaje
			// 
			this->btnMensaje->BackColor = System::Drawing::SystemColors::ActiveCaptionText;
			this->btnMensaje->Font = (gcnew System::Drawing::Font(L"Microsoft YaHei", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->btnMensaje->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->btnMensaje->Location = System::Drawing::Point(176, 109);
			this->btnMensaje->Name = L"btnMensaje";
			this->btnMensaje->Size = System::Drawing::Size(96, 32);
			this->btnMensaje->TabIndex = 2;
			this->btnMensaje->Text = L"MENSAJE";
			this->btnMensaje->UseVisualStyleBackColor = false;
			this->btnMensaje->Click += gcnew System::EventHandler(this, &Form1::btnMensaje_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(284, 261);
			this->Controls->Add(this->btnMensaje);
			this->Controls->Add(this->txtMensaje);
			this->Controls->Add(this->lblMensaje);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void label1_Click(System::Object^  sender, System::EventArgs^  e) {
			 }
	private: System::Void btnMensaje_Click(System::Object^  sender, System::EventArgs^  e) {
				 txtMensaje->Text="Hola Mundo";
			 }
	private: System::Void txtMensaje_TextChanged(System::Object^  sender, System::EventArgs^  e) {
			 }
	};
}

