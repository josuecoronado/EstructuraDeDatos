#include "StdAfx.h"
#include "VELOCIDAD.h"


VELOCIDAD::VELOCIDAD(void)
{
}

//Para accesar 
	int VELOCIDAD::Get_distancia()
	{
		return distancia;
	}
	int VELOCIDAD::Get_tiempo()
	{
		return tiempo;
	}
	int VELOCIDAD::Get_velocidad()
	{
		return velocidad;
	}


	void VELOCIDAD::Set_distancia(int d)
	{ 
		distancia=d; 
	}
	void VELOCIDAD::Set_tiempo(int t)
	{
		tiempo=t;
	}
	void VELOCIDAD::Set_velocidad(int v)
	{
		velocidad=v;
	}
	//Operaciones especificas
	int VELOCIDAD::Calcular()
	{
		velocidad=(distancia/tiempo);
		return velocidad;
	}
