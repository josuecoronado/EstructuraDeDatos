#pragma once
#include "VELOCIDAD.h"
#include <iostream> //Manejo de interaccion
#include "msclr\marshal_cppstd.h"
namespace formulavdt {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TextBox^  txtDistancia;
	protected: 
	private: System::Windows::Forms::TextBox^  txtTiempo;
	private: System::Windows::Forms::TextBox^  txtVelocidad;
	private: System::Windows::Forms::Button^  btnCalcular;
	private: System::Windows::Forms::Label^  lblDistancia;
	private: System::Windows::Forms::Label^  lblTiempo;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label4;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->txtDistancia = (gcnew System::Windows::Forms::TextBox());
			this->txtTiempo = (gcnew System::Windows::Forms::TextBox());
			this->txtVelocidad = (gcnew System::Windows::Forms::TextBox());
			this->btnCalcular = (gcnew System::Windows::Forms::Button());
			this->lblDistancia = (gcnew System::Windows::Forms::Label());
			this->lblTiempo = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->SuspendLayout();
			// 
			// txtDistancia
			// 
			this->txtDistancia->Location = System::Drawing::Point(122, 48);
			this->txtDistancia->Name = L"txtDistancia";
			this->txtDistancia->Size = System::Drawing::Size(62, 20);
			this->txtDistancia->TabIndex = 0;
			this->txtDistancia->TextChanged += gcnew System::EventHandler(this, &Form1::txtDistancia_TextChanged);
			// 
			// txtTiempo
			// 
			this->txtTiempo->Location = System::Drawing::Point(122, 91);
			this->txtTiempo->Name = L"txtTiempo";
			this->txtTiempo->Size = System::Drawing::Size(62, 20);
			this->txtTiempo->TabIndex = 1;
			// 
			// txtVelocidad
			// 
			this->txtVelocidad->Location = System::Drawing::Point(122, 136);
			this->txtVelocidad->Name = L"txtVelocidad";
			this->txtVelocidad->Size = System::Drawing::Size(62, 20);
			this->txtVelocidad->TabIndex = 2;
			// 
			// btnCalcular
			// 
			this->btnCalcular->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->btnCalcular->Location = System::Drawing::Point(161, 200);
			this->btnCalcular->Name = L"btnCalcular";
			this->btnCalcular->Size = System::Drawing::Size(79, 23);
			this->btnCalcular->TabIndex = 3;
			this->btnCalcular->Text = L"CALCULAR";
			this->btnCalcular->UseVisualStyleBackColor = true;
			this->btnCalcular->Click += gcnew System::EventHandler(this, &Form1::btnCalcular_Click);
			// 
			// lblDistancia
			// 
			this->lblDistancia->AutoSize = true;
			this->lblDistancia->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->lblDistancia->Location = System::Drawing::Point(13, 46);
			this->lblDistancia->Name = L"lblDistancia";
			this->lblDistancia->Size = System::Drawing::Size(95, 20);
			this->lblDistancia->TabIndex = 4;
			this->lblDistancia->Text = L"DISTANCIA";
			// 
			// lblTiempo
			// 
			this->lblTiempo->AutoSize = true;
			this->lblTiempo->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->lblTiempo->Location = System::Drawing::Point(13, 89);
			this->lblTiempo->Name = L"lblTiempo";
			this->lblTiempo->Size = System::Drawing::Size(69, 20);
			this->lblTiempo->TabIndex = 5;
			this->lblTiempo->Text = L"TIEMPO";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label3->Location = System::Drawing::Point(13, 134);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(103, 20);
			this->label3->TabIndex = 6;
			this->label3->Text = L"VELOCIDAD";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(190, 55);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(22, 13);
			this->label1->TabIndex = 7;
			this->label1->Text = L"Km";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(190, 98);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(35, 13);
			this->label2->TabIndex = 8;
			this->label2->Text = L"Horas";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(190, 143);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(41, 13);
			this->label4->TabIndex = 9;
			this->label4->Text = L"Km/hrs";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(284, 261);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->lblTiempo);
			this->Controls->Add(this->lblDistancia);
			this->Controls->Add(this->btnCalcular);
			this->Controls->Add(this->txtVelocidad);
			this->Controls->Add(this->txtTiempo);
			this->Controls->Add(this->txtDistancia);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnCalcular_Click(System::Object^  sender, System::EventArgs^  e) {
				 VELOCIDAD formulita;
		 formulita.Set_distancia(System::Convert::ToInt32(txtDistancia->Text));
		 formulita.Set_tiempo(System::Convert::ToInt32(txtTiempo->Text));
		 int velocidadfin;
		 velocidadfin=formulita.Calcular();
		 txtVelocidad->Text=System::Convert::ToString(velocidadfin);

			 }
private: System::Void txtDistancia_TextChanged(System::Object^  sender, System::EventArgs^  e) {
		 }
};
}