#pragma once
// el .h es cla estructura del programa que vamos a trabajar
class Cuadrado
{
	//Atributos
private:
	int lado;
	int area; //Analisis

public: //Metodos

	Cuadrado(void); //Constructor
	// Metodos de acceso (Get; Set)
	//Para accesar el contenido de los atributos
	int Get_lado();
	int Get_area();

	//Para darle valor a los atributos
	void Set_lado(int l);
	void Set_area(int a);

	//Operaciones especificas
	int Calcular();


};

